# -*- coding: utf-8 -*-
"""A minimal OSC client and server library for MicroPython."""
